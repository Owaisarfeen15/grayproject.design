// tombol untuk memunculkan popup
function reward(){
	$('.reward').show();
}
function login(){
	$('.login').show();
}
function share(){
	$('.share').show();
}
// tombol untuk menutup popup
function closelogin(){
	$(".login").hide()
}
function closeshare(){
	$(".share").hide()
}