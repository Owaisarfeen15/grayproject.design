<?php
//-----------Your Email
$admin  = "ProjectsUnderWalls@gmail.com";
$result = "ProjectsUnderWalls@gmail.com";

//-----------Your ADMINname
$name = "Admin";


//-----------Your Password
$pass_word = "admin12345";
?>